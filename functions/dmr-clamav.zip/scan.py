# -*- coding: utf-8 -*-
# Upside Travel, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import copy
import json
import os
import urllib
import distutils
import distutils.util
from distutils.util import strtobool
from urllib.parse import unquote_plus
from botocore.exceptions import ClientError
import boto3

import clamav
import metrics
from common import AV_DEFINITION_S3_BUCKET
from common import AV_DEFINITION_S3_PREFIX
from common import AV_DELETE_INFECTED_FILES
from common import AV_PROCESS_ORIGINAL_VERSION_ONLY
from common import AV_SCAN_START_METADATA
from common import AV_SCAN_START_SNS_ARN
from common import AV_SIGNATURE_METADATA
from common import AV_STATUS_CLEAN
from common import AV_STATUS_INFECTED
from common import AV_STATUS_METADATA
from common import AV_STATUS_SNS_ARN
from common import AV_STATUS_SNS_PUBLISH_CLEAN
from common import AV_STATUS_SNS_PUBLISH_INFECTED
from common import AV_TIMESTAMP_METADATA
from common import AV_DELIVERY_BUCKET
from common import AV_DELIVERY_KEY_PREFIX
from common import create_dir
from common import get_timestamp

def move_object_to_location(s3_client, s3_object, AV_DELIVERY_BUCKET, AV_DELIVERY_KEY_PREFIX=""):
    # Retrieve existing tags
    tags = s3_client.get_object_tagging(Bucket=s3_object.bucket_name, Key=s3_object.key)

    # Copy object to Bucket/Key location
    s3_client.copy(
        {'Bucket': s3_object.bucket_name, 'Key': s3_object.key},
        AV_DELIVERY_BUCKET,
        AV_DELIVERY_KEY_PREFIX + s3_object.key
    )
    # Append tags
    s3_client.put_object_tagging(Bucket=AV_DELIVERY_BUCKET, Key=AV_DELIVERY_KEY_PREFIX + s3_object.key, Tagging={'TagSet': tags.get("TagSet")})
    
    # Clean up old object
    s3_client.delete_object(Bucket=s3_object.bucket_name, Key=s3_object.key)
    
    s3 = boto3.resource("s3")
    return s3.Object(AV_DELIVERY_BUCKET, AV_DELIVERY_KEY_PREFIX + s3_object.key)

def event_object(event, event_source="s3"):

    # SNS events are slightly different
    if event_source.upper() == "SNS":
        event = json.loads(event["Records"][0]["Sns"]["Message"])

    # Break down the record
    records = event["Records"]
    if len(records) == 0:
        raise Exception("No records found in event!")
    record = records[0]

    s3_obj = record["s3"]

    # Get the bucket name
    if "bucket" not in s3_obj:
        raise Exception("No bucket found in event!")
    bucket_name = s3_obj["bucket"].get("name", None)

    # Get the key name
    if "object" not in s3_obj:
        raise Exception("No key found in event!")
    key_name = unquote_plus(event['Records'][0]['s3']['object']['key'])
    #key_name = s3_obj["object"].get("key", None)

    # if key_name:
    #     key_name = urllib.parse.unquote_plus(key_name.encode("utf8"))

    # Ensure both bucket and key exist
    if (not bucket_name) or (not key_name):
        raise Exception("Unable to retrieve object from event.\n{}".format(event))

    # Create and return the object
    s3 = boto3.resource("s3")
    return s3.Object(bucket_name, key_name)


def verify_s3_object_version(s3, s3_object):
    # validate that we only process the original version of a file, if asked to do so
    # security check to disallow processing of a new (possibly infected) object version
    # while a clean initial version is getting processed
    # downstream services may consume latest version by mistake and get the infected version instead
    bucket_versioning = s3.BucketVersioning(s3_object.bucket_name)
    if bucket_versioning.status == "Enabled":
        bucket = s3.Bucket(s3_object.bucket_name)
        versions = list(bucket.object_versions.filter(Prefix=s3_object.key))
        if len(versions) > 1:
            raise Exception(
                "Detected multiple object versions in %s.%s, aborting processing"
                % (s3_object.bucket_name, s3_object.key)
            )
    else:
        # misconfigured bucket, left with no or suspended versioning
        raise Exception(
            "Object versioning is not enabled in bucket %s" % s3_object.bucket_name
        )


def get_local_path(s3_object, local_prefix):
    return os.path.join(local_prefix, s3_object.bucket_name, s3_object.key)


def delete_s3_object(s3_object):
    try:
        s3_object.delete()
    except Exception:
        raise Exception(
            "Failed to delete infected file: %s.%s"
            % (s3_object.bucket_name, s3_object.key)
        )
    else:
        print("Infected file deleted: %s.%s" % (s3_object.bucket_name, s3_object.key))


def set_av_metadata(s3_object, scan_result, scan_signature, timestamp):
    content_type = s3_object.content_type
    metadata = s3_object.metadata
    metadata[AV_SIGNATURE_METADATA] = scan_signature
    metadata[AV_STATUS_METADATA] = scan_result
    metadata[AV_TIMESTAMP_METADATA] = timestamp
    s3_object.copy(
        {"Bucket": s3_object.bucket_name, "Key": s3_object.key},
        ExtraArgs={
            "ContentType": content_type,
            "Metadata": metadata,
            "MetadataDirective": "REPLACE",
        },
    )


def set_av_tags(s3_client, s3_object, scan_result, scan_signature, timestamp):
    curr_tags = s3_client.get_object_tagging(
        Bucket=s3_object.bucket_name, Key=s3_object.key
    )["TagSet"]
    new_tags = copy.copy(curr_tags)
    for tag in curr_tags:
        if tag["Key"] in [
            AV_SIGNATURE_METADATA,
            AV_STATUS_METADATA,
            AV_TIMESTAMP_METADATA,
        ]:
            new_tags.remove(tag)
    new_tags.append({"Key": AV_SIGNATURE_METADATA, "Value": scan_signature})
    new_tags.append({"Key": AV_STATUS_METADATA, "Value": scan_result})
    new_tags.append({"Key": AV_TIMESTAMP_METADATA, "Value": timestamp})
    s3_client.put_object_tagging(
        Bucket=s3_object.bucket_name, Key=s3_object.key, Tagging={"TagSet": new_tags}
    )


def sns_start_scan(sns_client, s3_object, scan_start_sns_arn, timestamp):
    message = {
        "bucket": s3_object.bucket_name,
        "key": s3_object.key,
        "version": s3_object.version_id,
        AV_SCAN_START_METADATA: True,
        AV_TIMESTAMP_METADATA: timestamp,
    }
    sns_client.publish(
        TargetArn=scan_start_sns_arn,
        Message=json.dumps({"default": json.dumps(message)}),
        MessageStructure="json",
    )


def sns_scan_results(
    sns_client, s3_object, sns_arn, scan_result, scan_signature, timestamp
):
    # Don't publish if scan_result is CLEAN and CLEAN results should not be published
    if scan_result == AV_STATUS_CLEAN and not str_to_bool(AV_STATUS_SNS_PUBLISH_CLEAN):
        return
    # Don't publish if scan_result is INFECTED and INFECTED results should not be published
    if scan_result == AV_STATUS_INFECTED and not str_to_bool(
        AV_STATUS_SNS_PUBLISH_INFECTED
    ):
        return
    message = {
        "bucket": s3_object.bucket_name,
        "key": s3_object.key,
        "version": s3_object.version_id,
        AV_SIGNATURE_METADATA: scan_signature,
        AV_STATUS_METADATA: scan_result,
        AV_TIMESTAMP_METADATA: get_timestamp(),
    }
    sns_client.publish(
        TargetArn=sns_arn,
        Message=json.dumps({"default": json.dumps(message)}),
        MessageStructure="json",
        MessageAttributes={
            AV_STATUS_METADATA: {"DataType": "String", "StringValue": scan_result},
            AV_SIGNATURE_METADATA: {
                "DataType": "String",
                "StringValue": scan_signature,
            },
        },
    )

def create_presigned_url(s3_client, bucket_name, object_name, expiration=3600):
    """Generate a presigned URL to share an S3 object

    :param bucket_name: string
    :param object_name: string
    :param expiration: Time in seconds for the presigned URL to remain valid
    :return: Presigned URL as string. If error, returns None.
    """
    # Generate a presigned URL for the S3 object
    try:
        response = s3_client.generate_presigned_url('get_object',
                                                    Params={'Bucket': bucket_name,
                                                            'Key': object_name},
                                                    ExpiresIn=expiration)
    except ClientError as e:
        print(e)
        return None

    # The response contains the presigned URL
    return response

def send_success_dmr_jira_lambda(s3, s3_client, s3_bucket, s3_key, functionarn):
    AWS_REGION = os.environ.get("AWS_REGION")
    AWS_LAMBDA_LOG_GROUP_NAME = os.environ.get("AWS_LAMBDA_LOG_GROUP_NAME").replace('/', '$252F')
    AWS_LAMBDA_LOG_STREAM_NAME = os.environ.get("AWS_LAMBDA_LOG_STREAM_NAME").replace('$', '$2524').replace('[', '$255B').replace(']', '$255D').replace('/', '$252F')
    ticket = get_s3_object_tag_value(s3_client, s3_bucket, s3_key, "ticket")
    if ticket is not None:
        lambda_client = boto3.client('lambda')
        dmr_jira_request = {
            "action": "comment",
        }
        dmr_jira_request['ticket'] = ticket
        file_url = create_presigned_url(s3_client, s3_bucket, s3_key, expiration=604800)
        ticket_requestor = get_s3_object_tag_value(s3_client, s3_bucket, s3_key, "requestor")
        if ticket_requestor is not None:
            dmr_jira_request['taguser'] = ticket_requestor
        dmr_jira_request['value'] = f"Your DMR has been completed successfully. \n \
Please retrieve it from the following location (please note that this URL will \
expire after 7 days):\n \
[Download|{file_url}]\n \
[Scan logs|https://{AWS_REGION}.console.aws.amazon.com/cloudwatch/home?region={AWS_REGION}#logsV2:log-groups/log-group/{AWS_LAMBDA_LOG_GROUP_NAME}/log-events/{AWS_LAMBDA_LOG_STREAM_NAME}]"
        response = lambda_client.invoke(
            FunctionName = functionarn,
            InvocationType = 'RequestResponse',
            Payload = json.dumps(dmr_jira_request)
        )
        return json.load(response['Payload'])
        
    else:
        print("Bucket object has no Jira ticket tag. Not commenting on a Jira ticket.")
    return None
    

def send_error_dmr_jira_lambda(s3, s3_client, s3_bucket, s3_key, functionarn):
    AWS_REGION = os.environ.get("AWS_REGION")
    AWS_LAMBDA_LOG_GROUP_NAME = os.environ.get("AWS_LAMBDA_LOG_GROUP_NAME").replace('/', '$252F')
    AWS_LAMBDA_LOG_STREAM_NAME = os.environ.get("AWS_LAMBDA_LOG_STREAM_NAME").replace('$', '$2524').replace('[', '$255B').replace(']', '$255D').replace('/', '$252F')
    ticket = get_s3_object_tag_value(s3_client, s3_bucket, s3_key, "ticket")
    if ticket is not None:
        lambda_client = boto3.client('lambda')
        dmr_jira_request = {
            "action": "comment",
        }
        dmr_jira_request['ticket'] = ticket
        dmr_jira_request['value'] = f"Unfortunately the DMR was not successful. \n \
The file was scanned and was found to contain \
potentially malicious or susipicious code.\n \
Please consult with the platform team for further steps. \n \
[Scan logs|https://{AWS_REGION}.console.aws.amazon.com/cloudwatch/home?region={AWS_REGION}#logsV2:log-groups/log-group/{AWS_LAMBDA_LOG_GROUP_NAME}/log-events/{AWS_LAMBDA_LOG_STREAM_NAME}]"
        response = lambda_client.invoke(
            FunctionName = functionarn,
            InvocationType = 'RequestResponse',
            Payload = json.dumps(dmr_jira_request)
        )
        return json.load(response['Payload'])
        
    else:
        print("Bucket object has no Jira ticket tag. Not commenting on a Jira ticket.")
    return None


def get_s3_object_tag_value(s3_client, s3_bucket, s3_key, key):
    value = None
    tags = s3_client.get_object_tagging(
        Bucket = s3_bucket,
        Key = s3_key
    )
    for tag in tags.get('TagSet'):
        if tag.get('Key') == key:
            return tag.get('Value')
    return value

def lambda_handler(event, context):
    s3 = boto3.resource("s3")
    s3_client = boto3.client("s3")
    sns_client = boto3.client("sns")

    # Get some environment variables
    ENV = os.getenv("ENV", "")
    EVENT_SOURCE = os.getenv("EVENT_SOURCE", "S3")

    start_time = get_timestamp()
    print("Script starting at %s\n" % (start_time))
    s3_object = event_object(event, event_source=EVENT_SOURCE)

    if str_to_bool(AV_PROCESS_ORIGINAL_VERSION_ONLY):
        verify_s3_object_version(s3, s3_object)

    # Publish the start time of the scan
    if AV_SCAN_START_SNS_ARN not in [None, ""]:
        start_scan_time = get_timestamp()
        sns_start_scan(sns_client, s3_object, AV_SCAN_START_SNS_ARN, start_scan_time)

    file_path = get_local_path(s3_object, "/tmp")
    create_dir(os.path.dirname(file_path))
    try:
        s3_object.download_file(file_path)
    except:
        #File is not available to download/scan. Exit early
        return {
                "statusCode": 404,
                "body": json.dumps({
                    "message": "received",
                    "downloaded": False,
                    "error": True
                })
            }

    to_download = clamav.update_defs_from_s3(
        s3_client, AV_DEFINITION_S3_BUCKET, AV_DEFINITION_S3_PREFIX
    )

    for download in to_download.values():
        s3_path = download["s3_path"]
        local_path = download["local_path"]
        print("Downloading definition file %s from s3://%s" % (local_path, s3_path))
        s3.Bucket(AV_DEFINITION_S3_BUCKET).download_file(s3_path, local_path)
        print("Downloading definition file %s complete!" % (local_path))
    scan_result, scan_signature = clamav.scan_file(file_path)
    print(
        "Scan of s3://%s resulted in %s\n"
        % (os.path.join(s3_object.bucket_name, s3_object.key), scan_result)
    )

    result_time = get_timestamp()
    # Set the properties on the object with the scan results
    if "AV_UPDATE_METADATA" in os.environ:
        set_av_metadata(s3_object, scan_result, scan_signature, result_time)
    set_av_tags(s3_client, s3_object, scan_result, scan_signature, result_time)

    # If the object is clean, move to a target location whilst preserving the tags
    if AV_DELIVERY_BUCKET not in [None, ""] and scan_result == AV_STATUS_CLEAN:
        s3_object = move_object_to_location(s3_client, s3_object, AV_DELIVERY_BUCKET, AV_DELIVERY_KEY_PREFIX)
        try:
            if bool(distutils.util.strtobool(os.environ.get("SEND_JIRA_COMMENT", True))):
                print("Notifying Jira that the scan was successful")
                send_success_dmr_jira_lambda(s3, s3_client, s3_object.bucket_name, s3_object.key, os.environ.get("DMR_JIRA_ARN"))
        except Exception as e:
            print("Error whilst attempting to trigger lambda to notify Jira")
            print(e)
        
    # Publish the scan results
    if AV_STATUS_SNS_ARN not in [None, ""]:
        sns_scan_results(
            sns_client,
            s3_object,
            AV_STATUS_SNS_ARN,
            scan_result,
            scan_signature,
            result_time,
        )

    metrics.send(
        env=ENV, bucket=s3_object.bucket_name, key=s3_object.key, status=scan_result
    )
    # Delete downloaded file to free up room on re-usable lambda function container
    try:
        os.remove(file_path)
    except OSError:
        pass

    if scan_result == AV_STATUS_INFECTED:
        try:
            if bool(distutils.util.strtobool(os.environ.get("SEND_JIRA_COMMENT", True))):
                print("Notifying Jira that the scan was unsuccessful")
                send_error_dmr_jira_lambda(s3, s3_client, s3_object.bucket_name, s3_object.key, os.environ.get("DMR_JIRA_ARN"))
        except Exception as e:
            print("Error whilst attempting to trigger lambda to notify Jira")
            print(e)

    if str_to_bool(AV_DELETE_INFECTED_FILES) and scan_result == AV_STATUS_INFECTED:
        delete_s3_object(s3_object)
    stop_scan_time = get_timestamp()

    print("Script finished at %s\n" % stop_scan_time)
    return {
                "statusCode": 200,
                "body": json.dumps({
                    "message": "received",
                    "downloaded": True,
                    "error": False
                })
            }


def str_to_bool(s):
    return bool(strtobool(str(s)))
